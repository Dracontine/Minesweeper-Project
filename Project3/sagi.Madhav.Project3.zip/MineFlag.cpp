#include "MineFlag.h"

Flag::Flag() {
	setSprite("flag");
}