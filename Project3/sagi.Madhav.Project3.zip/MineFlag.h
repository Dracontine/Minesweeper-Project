#pragma once
#include "Tile.h"
class Flag : public Tile
{
public:
	Flag(); //parent constructor
};

