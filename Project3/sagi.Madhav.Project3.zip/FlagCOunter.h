#pragma once
#include "Tile.h"
class FlagCounter : public Tile
{
public: //counts the number of flags left
	FlagCounter(int);
};



