#include "Mine.h"

Mine::Mine() {
	setSprite("mine"); //makes mine
}
#include "Mine.h"
