#pragma once
#include "Tile.h"
class numberOfMinesNear : public Tile
{
public:
	numberOfMinesNear(int);  // flood method which get the tiles and it puts numbers based off how manyu tiles are near it
};

