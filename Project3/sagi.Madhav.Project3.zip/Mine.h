#pragma once
#include "Tile.h"
class Mine : public Tile
{
public:
	Mine(); // mine object  creation and places it
};

